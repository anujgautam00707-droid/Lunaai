const chat = document.getElementById("chat");
const form = document.getElementById("form");
const input = document.getElementById("input");
const sendBtn = document.getElementById("sendBtn");
const clearBtn = document.getElementById("clearBtn");

let history = [];

function addMessage(text, role) {
  const el = document.createElement("div");
  el.className = `message ${role === "user" ? "user" : "assistant"}`;
  el.textContent = text;
  chat.appendChild(el);
  chat.scrollTop = chat.scrollHeight;
}

function addTyping() {
  const el = document.createElement("div");
  el.className = "message assistant typing";
  el.id = "typing";
  el.innerHTML = "<i></i><i></i><i></i>";
  chat.appendChild(el);
  chat.scrollTop = chat.scrollHeight;
}

function resizeInput() {
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 130) + "px";
}

async function send(message) {
  const text = message.trim();
  if (!text || sendBtn.disabled) return;

  addMessage(text, "user");
  history.push({ role: "user", content: text });

  input.value = "";
  resizeInput();
  sendBtn.disabled = true;
  addTyping();

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: text,
        history: history.slice(-8)
      })
    });

    const data = await response.json();
    document.getElementById("typing")?.remove();

    if (!response.ok) throw new Error(data.error || "Could not get a reply.");

    const reply = data.reply || "I couldn't generate a reply.";
    addMessage(reply, "assistant");
    history.push({ role: "assistant", content: reply });
  } catch (error) {
    document.getElementById("typing")?.remove();
    addMessage(
      "Luna couldn't connect to Workers AI. Make sure your Cloudflare Pages project has a Workers AI binding named AI, then redeploy.",
      "assistant"
    );
    console.error(error);
  } finally {
    sendBtn.disabled = false;
    input.focus();
  }
}

form.addEventListener("submit", e => {
  e.preventDefault();
  send(input.value);
});

input.addEventListener("input", resizeInput);
input.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    form.requestSubmit();
  }
});

document.querySelectorAll(".chips button").forEach(button => {
  button.addEventListener("click", () => send(button.dataset.message));
});

clearBtn.addEventListener("click", () => {
  history = [];
  chat.innerHTML = "";
  welcome();
});

function welcome() {
  addMessage(
    "Hi 💜 I'm Luna. Tell me what's bothering you during your period and I'll give practical comfort tips. You can talk normally — you don't need specific keywords.",
    "assistant"
  );
}

welcome();
input.focus();
