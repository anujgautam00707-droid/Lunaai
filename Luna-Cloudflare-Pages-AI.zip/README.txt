LUNA AI — CLOUDFLARE PAGES VERSION

IMPORTANT:
This version does NOT need Netlify.
It also does NOT need your API token pasted into the website.

FILES
-----
index.html
style.css
script.js
functions/api/chat.js

The /functions folder is required.

SETUP
-----

1. Log into Cloudflare.

2. Go to Workers & Pages.

3. Create a Pages project.

4. Deploy this project with Git/GitHub so Cloudflare can include the /functions folder.
   Keep the folder structure unchanged.

5. After the Pages project exists, open:
   Project > Settings > Bindings

6. Add a Workers AI binding.

7. Set the Variable name EXACTLY to:
   AI

8. Save.

9. Redeploy the Pages project.

10. Open the generated pages.dev URL and test Luna.

TEST MESSAGE
------------
I have cramps and feel tired. What can I do?

If Luna says the AI binding is missing:
- Check the binding is named exactly AI
- Redeploy after adding it

SECURITY
--------
Do not put your Cloudflare API token in index.html, script.js, or chat.js.
The direct Workers AI binding handles access from your Pages Function.
